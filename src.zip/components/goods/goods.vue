<template>

  <div>iamgoods</div>
</template>

<script>
export default {
  name: "goods"
}
</script>

<style scoped>

</style>
