<template>
  <div>iamratings</div>

</template>

<script>
export default {
  name: "ratings"
}
</script>

<style scoped>

</style>
