<template>

  <div>iamseller</div>
</template>

<script>
export default {
  name: "seller"
}
</script>

<style scoped>

</style>
